
/*
 12. In a company an employee is paid as under: If his basic salary is less than 
Rs. 10000, then HRA = 10% of basic salary and DA = 90% of basic salary. If 
his salary is either equal to or above Rs. 10000, then HRA = Rs. 2000 and DA 
= 98% of basic salary. If the employee's salary is input by the user write a 
program to find his gross salary. [ formula : GS= Basic + DA + HRA ]*/

import java.util.Scanner;

public class Q12 {

	public static void main(String[] args) {
        
		Scanner sc = new Scanner(System.in);
		Double bs, gs, da, hra;
		System.out.println("Enter employee's basic salary (In Rs.):");
		bs =sc.nextDouble();
		if (bs<10000)
		{
			hra = bs * 10 / 100;
			da = bs * 90 / 100;
		}
	     else
		{
			hra = (double) 2000;
			da = bs * 98 / 100;
		}
	   gs = bs + hra + da;
	  
	   System.out.println("Gross salary = "+ gs);
		
		

	}

}
