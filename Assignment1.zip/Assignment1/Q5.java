/*
05.	Write a program that takes user�s name as command line argument and prints Welcome <entered user name>.
*/

class Q5{
	public static void main(String args[]){
		
		System.out.println("Welcome "+args[0]);
	}
}