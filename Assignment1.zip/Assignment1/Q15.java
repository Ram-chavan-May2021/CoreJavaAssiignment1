/*
15.	Accept person�s gender (character m for male and f for female), age (integer), 
as input and then check whether person is eligible for marriage or not.
*/

import java.util.Scanner;

public class Q15 {	
	public static void main(String args[]) {
		Scanner sc =new Scanner(System.in);
		System.out.println("Enter the person�s gender: ");
		char gender = sc.next().charAt(0);
		System.out.println("Enter the person�s age: ");
		int age = sc.nextInt();
		if(((gender=='F' || gender=='f') && age>=18) || ((gender=='M' || gender=='m') && age>=21)) {
			System.out.println("Eligible for marriage");
		}
		else
		{
			System.out.println("Nikal.. Pehli fursat me nikal");
		}
	}
}